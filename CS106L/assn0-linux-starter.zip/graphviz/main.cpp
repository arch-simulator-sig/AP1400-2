#include <iostream>
#include "GraphVisualizer.h"
using namespace std;

void Welcome() {
	cout << "Welcome to CS106L GraphViz!" << endl;
	cout << "This program uses a force-directed graph layout algorithm" << endl;
  cout << "to render sleek, snazzy pictures of various graphs." << endl;
  cout << endl;
}

int main() {
	Welcome();
  
  /* TODO: Your implementation goes here! */

  return 0;
}
