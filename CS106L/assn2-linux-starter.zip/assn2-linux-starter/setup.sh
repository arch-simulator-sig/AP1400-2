#!/bin/bash
cd color-naming && qmake && cd ..
cd digit-classifier && qmake && cd ..
cd map-lookup && qmake && cd ..
